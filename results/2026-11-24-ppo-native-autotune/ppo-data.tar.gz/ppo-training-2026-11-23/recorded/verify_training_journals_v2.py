"""Independent arithmetic check of saved training transitions; no policy execution."""
import hashlib,json,math,datetime
from pathlib import Path

base=Path(__file__).parent
source=Path('outputs/operator-generalization-20261123-compile-isolation/primary-collection-recovered-01/evidence/table.json')
table=json.loads(source.read_text())
train_ids={t['id'] for t in table['suite']['tasks'] if t['split']=='train'}
candidates=table['suite']['candidates']
rows={(r['measurement']['task_id'],r['measurement']['candidate_id'],r['repeat_index']):r['measurement'] for r in table['rows']}
summary=[]
for seed in range(3101,3106):
 directory=base/'training'/f'seed-{seed}'
 manifest=json.loads((directory/'manifest.json').read_text())
 assert hashlib.sha256((directory/'model.zip').read_bytes()).hexdigest()==manifest['checkpoint_sha256']
 assert manifest['training_timesteps']==manifest['actual_environment_steps']==102400
 assert manifest['parameters_changed'] and manifest['parameter_delta_l2']>0
 assert set(manifest['training']['task_ids'])==train_ids
 episodes=steps=0;seen_tasks=set()
 worker_episode={i:0 for i in range(4)}
 with (directory/'training-episodes.jsonl').open() as f:
  for line in f:
   episode=json.loads(line); task=episode['task_id']; assert task in train_ids
   assert episode['episode']==worker_episode[episode['worker']]
   worker_episode[episode['worker']]+=1
   seen_tasks.add(task)
   replay_seed=episode['replay_seed'];ref=rows[(task,None,replay_seed%3)]
   assert episode['baseline_source_trial_id']==ref['trial_id']
   assert len(episode['transitions'])==8
   best=1.;selected=None;counts={};reward_sum=0.
   for tr in episode['transitions']:
    action=tr['action'];cid=candidates[action]['id']
    repeat=(replay_seed+counts.get(action,0))%3;counts[action]=counts.get(action,0)+1
    r=rows[(task,cid,repeat)]
    assert tr['source_trial_id']==r['trial_id'] and tr['source_repeat_index']==repeat
    reward=0.
    if r['status']=='ok':
     cost=r['latency_ms']/ref['latency_ms']
     if cost<best:reward=best-cost;best=cost;selected=cid
    assert math.isclose(tr['reward'],reward,rel_tol=0,abs_tol=1e-14)
    assert math.isclose(tr['incumbent_cost'],best,rel_tol=0,abs_tol=1e-14)
    steps+=1;reward_sum+=reward
   assert math.isclose(episode['reward_sum'],reward_sum,rel_tol=0,abs_tol=1e-14)
   assert episode['final_candidate_id']==selected
   episodes+=1
 assert episodes==12800 and steps==102400 and seen_tasks==train_ids
 summary.append({'seed':seed,'completed_episodes':episodes,'steps':steps,'observed_train_tasks':len(seen_tasks),
                 'worker_completed_episodes':worker_episode,'parameter_delta_l2':manifest['parameter_delta_l2'],
                 'checkpoint_sha256':manifest['checkpoint_sha256']})
receipt={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_passed':True,
         'all_training_transitions_recomputed':512000,'train_only_tasks':30,
         'source_table_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'seeds':summary,
         'scope':'Recorded TRAIN-only replay sources, per-candidate repeat cycling, every reward/incumbent and budget; not fresh GPU evidence',
         'sb3_terminal_reset_note':'Four final baseline-only automatic resets per seed are reflected in manifest task episode-start counts; completed episode journals and actual timestep counts exclude those unused resets.'}
(base/'training-journals-verified.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
