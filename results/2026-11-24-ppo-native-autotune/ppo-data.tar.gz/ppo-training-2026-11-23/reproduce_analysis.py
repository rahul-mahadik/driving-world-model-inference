#!/usr/bin/env python3
"""Recompute the ten-report comparison without new measurements or training."""
import argparse
import importlib.util
import json
from pathlib import Path
from drivebench_tuning.suite import load_suite

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', required=True, type=Path)
args = p.parse_args()
root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('recorded_ppo_analysis', root / 'analysis-source/ppo_analysis.py')
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
paths = sorted((root / 'recorded/evaluation').glob('ppo-*.json'))
paths += sorted((root / 'recorded-baselines').glob('*.json'))
if len(paths) != 10:
    raise ValueError('Exactly six PPO and four original baseline reports required')
result = analysis.replay_comparison([json.loads(path.read_text()) for path in paths], load_suite('operator-generalization-v2'))
with args.output.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
