# Recorded PPO supplement

This archive preserves five trained PPO checkpoints, one untrained control,
their training journals and manifests, six held-out replay reports, four
original CPU baseline reports, and the exact nine source files frozen before
training. These are CPU replay results on an already measured GPU table;
they do not add independent GPU measurements.

## Recompute the comparison

From a DriveBench repository checkout with the operator extension dependencies
installed, run (adjust the extracted archive path):

```sh
PYTHONPATH=extensions/kernel_tuning python ppo-training-2026-11-23/reproduce_analysis.py --output replay-summary.json
```

The command uses all ten reports and the archived analysis implementation.
All reports retain the same original measured-table SHA. The source-bindings
file maps that table and every original measurement hash to the separately
published table, whose provider identities were pseudonymized. The performance,
correctness, inputs, trial identifiers and decisions are unchanged.

For historical training reproduction, overlay the nine files under
recorded/frozen-source on repository commit
798167719fe5ff382cf258ced7cbee748e9ce62c. Training dependencies and settings are
recorded in recorded/protocol.json. Use evaluation/summary-corrected.json;
the original summary and its correction receipt are retained.

The only changed recorded artifact is a diagnostic log with its workstation
prefix replaced by <local-project>. Checkpoints, JSON, journals and source
remain byte-exact. A privacy-scan receipt retains its literal pattern names;
these names are its checklist, not matched credentials or private paths.
