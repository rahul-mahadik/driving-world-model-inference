#!/usr/bin/env python3
"""Offline analysis of archived public scientific results."""
import argparse, importlib.util, json, sys
from pathlib import Path
import drivebench_tuning
from drivebench_tuning.suite import load_suite
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
r = Path(__file__).resolve().parent
for name, filename in [('drivebench_tuning.native_audit', 'native_audit.py'), ('drivebench_tuning._archived_live_analysis', 'ppo_analysis.py')]:
    spec = importlib.util.spec_from_file_location(name, r / 'analysis-source' / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
reports = [json.loads((r / f'repeat-{i}/result.json').read_text()) for i in range(3)]
summary = module.live_comparison(reports, load_suite('operator-generalization-v2'))
with a.output.open('x') as stream:
    json.dump(summary, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
