# Fresh PPO versus native Triton autotuning

This archive contains a separate three-process GPU cohort. It preserves every
native configuration timing, PPO observation/action/measurement, reference
fallback probe, and fresh confirmation, including rejected configurations.
The public copies pseudonymize GPU identifiers and their derived cohort hash;
trial identifiers, numerical measurements, correctness and input hashes are
unchanged. Exception messages are redacted; error classes and failed outcomes
remain. Private provider, SSH and host-operation files are excluded.

Native autotuning tests all 24 Triton configurations plus three reference
fallback probes. PPO uses a fixed trained checkpoint and eight live queries.
These are different search budgets. Confirmed latency differences are not
regret against a fresh full-grid oracle, and operator results are not Vista
end-to-end or perceptual-quality measurements.

Selection wall times are instrumented harness costs. PPO evaluator trials
flush journal records for every CUDA sample, while native tuning journals each
configuration. Within each process, selectors share compile caches and their
order alternates. Therefore these wall times do not isolate intrinsic search
algorithm efficiency or cold compilation cost. Offline PPO training is
reported separately in the companion PPO archive.

From a DriveBench checkout with the operator dependencies installed:

```sh
PYTHONPATH=extensions/kernel_tuning python ppo-native-live-2026-11-23/reproduce_analysis.py --output reproduced-live.json
```

The command uses the archived analysis and audit code with the public suite.
The frozen native module, exact input bindings and scientific protocol are
included. The scientific protocol omits only allocation and credential-access
constraints; query counts, repetition counts and measurement budgets remain.
